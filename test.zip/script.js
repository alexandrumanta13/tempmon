let values = [
    { day: "6", hour: "0", current_temp: "29" },
    { day: "6", hour: "1", current_temp: "29" },
    { day: "6", hour: "2", current_temp: "29" },
    { day: "6", hour: "3", current_temp: "29" },
    { day: "6", hour: "4", current_temp: "29" },
    { day: "6", hour: "5", current_temp: "29" },
    { day: "6", hour: "7", current_temp: "29" },
]


let hours = [];
for (let i = 0; i < 24; i++) {
    hours[i] = { current_temp: 0, hour: i, offline: 1 };
    hours['length'] = 24;
}

let tempArr = values.map((i, idx) => {
    return parseInt(values[idx].hour);
})

let hoursArr = hours.map((i, idx) => {
    return hours[idx].hour;
})

hoursArr.filter((hour, idx) => {
    if (!tempArr.includes(hour)) {
        if (hours[idx].hour == hour) {
            hours[idx].offline = 0;
            hours[idx].current_temp = null;
        }
    } else {
        console.log(values[idx].current_temp)
        hours[idx].offline = 1;
        hours[idx].current_temp = values[idx].current_temp;
    }
});

console.log(hours)