<?PHP



$conect = @mysql_connect($server,$username,$pass);
if(!$conect)
	{
	echo "Does not connect to $server with $nume";
	exit;
	}
if(!mysql_select_db($database,$conect))
	{
	echo "Does not select $db because ",mysql_error($conect);
	exit;
	}

