<?PHP
session_start();
$_SESSION['time'] = time();