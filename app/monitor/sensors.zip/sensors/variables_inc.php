<?PHP

$include_path="inc/";
$server="localhost";
$database="";
$username="";
$pass="";
$tableName="temperature_";